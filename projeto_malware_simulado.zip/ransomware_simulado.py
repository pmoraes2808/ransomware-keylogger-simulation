import os
import base64

PASTA_ALVOS = "samples"
PASTA_BACKUP = "backup_simulado"
os.makedirs(PASTA_BACKUP, exist_ok=True)

def criptografar_simulado(caminho_arquivo):
    with open(caminho_arquivo, "rb") as f:
        conteudo = f.read()
    conteudo_criptografado = base64.b64encode(conteudo)
    with open(caminho_arquivo, "wb") as f:
        f.write(conteudo_criptografado)

def descriptografar_simulado(caminho_arquivo):
    with open(caminho_arquivo, "rb") as f:
        conteudo = f.read()
    conteudo_original = base64.b64decode(conteudo)
    with open(caminho_arquivo, "wb") as f:
        f.write(conteudo_original)

def executar_ransomware_simulado():
    for arquivo in os.listdir(PASTA_ALVOS):
        caminho_completo = os.path.join(PASTA_ALVOS, arquivo)
        if os.path.isfile(caminho_completo):
            os.rename(caminho_completo, os.path.join(PASTA_BACKUP, arquivo))
            backup_path = os.path.join(PASTA_BACKUP, arquivo)
            criptografar_simulado(backup_path)
            with open(backup_path, "rb") as f:
                conteudo = f.read()
            with open(caminho_completo, "wb") as f:
                f.write(conteudo)
    with open("README_RESCUE.txt", "w") as f:
        f.write("Seus arquivos foram criptografados!
Pague 0.0 BTC para recuperar (simulação).")

def restaurar_arquivos():
    for arquivo in os.listdir(PASTA_BACKUP):
        caminho_completo = os.path.join(PASTA_BACKUP, arquivo)
        if os.path.isfile(caminho_completo):
            descriptografar_simulado(caminho_completo)
            with open(caminho_completo, "rb") as f:
                conteudo = f.read()
            with open(os.path.join(PASTA_ALVOS, arquivo), "wb") as f:
                f.write(conteudo)

if __name__ == "__main__":
    executar_ransomware_simulado()
    # restaurar_arquivos()
