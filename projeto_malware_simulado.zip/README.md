# 💻 Simulação de Malware com Python (Educacional)

> Projeto criado para fins educacionais, com o objetivo de estudar o funcionamento de ameaças digitais (ransomware e keylogger) em ambiente **controlado** e de forma **ética e segura**.

## 🎯 Objetivos
- Simular o comportamento básico de ransomware e keylogger.
- Demonstrar como essas ameaças funcionam internamente.
- Refletir sobre como nos defender de ataques reais.
- Desenvolver portfólio técnico em cibersegurança.

## 📁 Estrutura do Projeto
- `samples/` - Arquivos alvo
- `backup_simulado/` - Backup dos arquivos
- `images/` - Capturas de tela
- `ransomware_simulado.py` - Script de ransomware simulado
- `keylogger_simulado.py` - Script de keylogger simulado
- `README_RESCUE.txt` - Mensagem de resgate gerada
- `log_simulado.txt` - Log de teclas simulado

## ⚠️ Aviso Legal
Este projeto é **estritamente educacional**. Não execute fora de ambiente controlado.
