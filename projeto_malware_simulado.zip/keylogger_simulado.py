import time

teclas_simuladas = ["h", "e", "l", "l", "o", " ", "w", "o", "r", "l", "d", "\n"]

def simular_keylogger():
    with open("log_simulado.txt", "a") as f:
        for tecla in teclas_simuladas:
            f.write(tecla)
            print(f"[LOG] Capturado: {tecla}")
            time.sleep(0.3)

def enviar_email_simulado():
    print("[EMAIL] Simulação de envio de email com o log para: admin@exemplo.com")

if __name__ == "__main__":
    simular_keylogger()
    enviar_email_simulado()
